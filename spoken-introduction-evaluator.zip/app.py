import streamlit as st

st.title("Spoken Introduction Evaluation Tool")

transcript = st.text_area("Paste Student Transcript Here")

if st.button("Evaluate"):
    clarity = 4
    relevance = 3
    grammar = 4
    confidence = 3
    structure = 4

    final_score = clarity + relevance + grammar + confidence + structure

    st.subheader("Evaluation Result")
    st.write(f"Clarity: {clarity}/5")
    st.write(f"Relevance: {relevance}/5")
    st.write(f"Grammar & Fluency: {grammar}/5")
    st.write(f"Confidence: {confidence}/5")
    st.write(f"Structure: {structure}/5")
    st.success(f"Final Score: {final_score}/25")
